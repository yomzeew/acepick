import { Text, View } from "react-native"
import LoginComponent from "../../component/logincomponent";

const LoginPage=()=>{
    return(
        <View>  
            <LoginComponent/>
        </View>
    )
    
}
export default LoginPage