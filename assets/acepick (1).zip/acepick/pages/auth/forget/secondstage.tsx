import { View, Text } from 'react-native'
import ForgetOtp from '../../../component/forgetotp'

const VerifyOtpPage = () => {
  return (
    <View>
        <ForgetOtp/>
    </View>
  )
}

export default VerifyOtpPage
