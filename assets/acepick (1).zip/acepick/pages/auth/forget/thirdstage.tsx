import { View, Text } from 'react-native'
import CreateNewPasswordcomponent from '../../../component/createnewpasswordcomponent'

const ChangePasswordPage = () => {
  return (
    <View>
        <CreateNewPasswordcomponent/>
    </View>
  )
}

export default ChangePasswordPage
