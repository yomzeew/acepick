import { View, Text } from 'react-native'
import PasswordChangeSuccessComponent from '../../../component/passwordchangesuccess'

const PasswordSuccessPage = () => {
  return (
    <View>
        <PasswordChangeSuccessComponent/>
    </View>
  )
}

export default PasswordSuccessPage
