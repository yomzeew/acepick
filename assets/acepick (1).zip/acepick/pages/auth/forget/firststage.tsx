import { View, Text } from 'react-native'
import React from 'react'
import RecoverPassword from '../../../component/recoverpasswordcomponent'

const RecoverPasswordPage = () => {
  return (
    <View>
        <RecoverPassword/>
    </View>
  )
}

export default RecoverPasswordPage
