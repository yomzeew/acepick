import { Text, View } from "react-native"
import FirstStagecomponent from "../../../component/firststagecomponent";

const FirstStage=()=>{
    return(
        <View>  
            <FirstStagecomponent/>
        </View>
    )
    
}
export default FirstStage