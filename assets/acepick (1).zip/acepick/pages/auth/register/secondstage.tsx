import { Text, View } from "react-native"
import SecondStageComponent from "../../../component/secondstagecomponent"

const SecondStage=()=>{
    return(
        <View>  
            <SecondStageComponent/>
        </View>
    )
    
}
export default SecondStage