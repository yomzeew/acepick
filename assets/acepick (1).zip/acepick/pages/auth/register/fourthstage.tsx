import { Text, View } from "react-native"
import VerificationSuccessScreen from "../../../component/verificationsuccesscomponent"

const FourthStage=()=>{
    return(
        <View>  
            <VerificationSuccessScreen/>
        </View>
    )
    
}
export default FourthStage
