import { Text, View } from "react-native"
import AccountSuccessScreen from "../../../component/accountcreationsuccesscomponent"
const LastStage=()=>{
    return(
        <View>  
            <AccountSuccessScreen/>
        </View>
    )
    
}
export default LastStage
