import { Text, View } from "react-native"
import PasswordConfirmcomponent from "../../../component/passwordconfirmcomponent"
const FifthStage=()=>{
    return(
        <View>  
            <PasswordConfirmcomponent/>
        </View>
    )
    
}
export default FifthStage
