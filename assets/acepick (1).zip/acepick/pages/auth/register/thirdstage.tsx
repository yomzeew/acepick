import { Text, View } from "react-native"
import ThirdStageComponent from "../../../component/thirdstagecomponent"

const ThirdStage=()=>{
    return(
        <View>  
            <ThirdStageComponent/>
        </View>
    )
    
}
export default ThirdStage