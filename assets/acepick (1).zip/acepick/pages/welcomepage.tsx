import WelcomeComponent from "../component/welcomecomponent";
const WelcomePage = ()=>{
return(
    <WelcomeComponent/>
)
}
export default WelcomePage;