import Splash from "../component/splash"
const SplashScreen = ()=>{
return(
    <Splash/>
)
}
export default SplashScreen;