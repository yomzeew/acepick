import { View } from 'react-native'
const EmptyView = () => {
  return (
    <View className='h-16'></View>
  )
}

export default EmptyView