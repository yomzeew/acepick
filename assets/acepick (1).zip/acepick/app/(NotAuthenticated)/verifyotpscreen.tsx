import { View } from "react-native"
import VerifyOtpPage from "../../pages/auth/forget/secondstage"
const VerifyOtpScreen=()=>{
    return(
        <>
        <View>
           <VerifyOtpPage/>
        </View>
        </>
    )
}
export default VerifyOtpScreen