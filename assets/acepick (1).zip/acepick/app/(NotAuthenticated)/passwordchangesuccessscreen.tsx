import { View, Text } from 'react-native'
import PasswordSuccessPage from '../../pages/auth/forget/laststage'
const PasswordSuccessScreen = () => {
  return (
    <>
    <View>
       <PasswordSuccessPage/>
    </View>
    </>
  )
}

export default PasswordSuccessScreen

