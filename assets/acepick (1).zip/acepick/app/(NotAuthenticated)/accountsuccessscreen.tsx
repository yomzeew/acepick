import { View, Text } from 'react-native'
import LastStage from '../../pages/auth/register/laststage'
const AccountSuccessScreen = () => {
  return (
    <>
    <View>
       <LastStage/>
    </View>
    </>
  )
}

export default AccountSuccessScreen
