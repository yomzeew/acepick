import { View, Text } from 'react-native'
import FifthStage from '../../pages/auth/register/fifthstage'
const passwordconfirmscreen = () => {
  return (
    <>
    <View>
       <FifthStage/>
    </View>
    </>
  )
}

export default passwordconfirmscreen

