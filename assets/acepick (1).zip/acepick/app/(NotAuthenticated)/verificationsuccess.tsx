import { View } from "react-native"
import FourthStage from "../../pages/auth/register/fourthstage"
const VerificationSuccessScreen=()=>{
    return(
        <>
        <View>
           <FourthStage/>
        </View>
        </>
    )
}
export default VerificationSuccessScreen