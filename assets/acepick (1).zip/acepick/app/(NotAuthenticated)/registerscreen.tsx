import { View } from "react-native"
import FirstStage from "../../pages/auth/register/firststage"
const loginScreen=()=>{
    return(
        <>
        <View>
           <FirstStage/>
        </View>
        </>
    )
}
export default loginScreen