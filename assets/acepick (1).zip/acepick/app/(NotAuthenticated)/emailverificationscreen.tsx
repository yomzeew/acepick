import { View } from "react-native"
import SecondStage from "../../pages/auth/register/secondstage"
const EmailVerificationScreen=()=>{
    return(
        <>
        <View>
           <SecondStage/>
        </View>
        </>
    )
}
export default EmailVerificationScreen