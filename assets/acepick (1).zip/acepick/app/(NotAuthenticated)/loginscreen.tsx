import { View } from "react-native"
import LoginPage from "../../pages/auth/login"
const loginScreen=()=>{
    return(
        <>
        <View>
           <LoginPage/>
        </View>
        </>
    )
}
export default loginScreen