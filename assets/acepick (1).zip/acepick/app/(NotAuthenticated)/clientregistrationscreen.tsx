import { View, Text } from 'react-native'
import ThirdStage from '../../pages/auth/register/thirdstage'
const clientregistrationscreen = () => {
  return (
    <>
    <View>
       <ThirdStage/>
    </View>
    </>
  )
}

export default clientregistrationscreen
