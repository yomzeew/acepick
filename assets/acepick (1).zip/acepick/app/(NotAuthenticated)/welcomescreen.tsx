import { View } from "react-native"
import WelcomePage from "../../pages/welcomepage"
const WelcomeScreen=()=>{
    return(
        <>
        <View>
           <WelcomePage/>
        </View>
        </>
    )
}
export default WelcomeScreen