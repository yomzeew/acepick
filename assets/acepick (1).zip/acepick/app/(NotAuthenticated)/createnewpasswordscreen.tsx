import { View, Text } from 'react-native'
import ChangePasswordPage from '../../pages/auth/forget/thirdstage'


const Createnewpasswordscreen = () => {
  return (
    <View>
      <ChangePasswordPage/>
    </View>
  )
}

export default Createnewpasswordscreen