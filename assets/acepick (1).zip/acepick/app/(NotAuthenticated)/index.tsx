import { View } from "react-native"
import SplashScreen from "../../pages/splashscreen"
const HomeScreen=()=>{
    return(
        <>
        <View>
           <SplashScreen/>
        </View>
        </>
    )
}
export default HomeScreen