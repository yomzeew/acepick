import { Text } from "react-native"

const LoginRoute=()=>{
    return(
        <>
        
        </>
    )
}
export default LoginRoute